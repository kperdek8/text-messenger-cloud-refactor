const { Pool } = await import('pg');
import { validate as isUuid } from 'uuid';

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: 5432,
  ssl: { rejectUnauthorized: false }
});


export const handler = async (event) => {
  const client = await pool.connect();

  try {
    const userId =
          event.requestContext?.authorizer?.jwt?.claims?.sub ??
          event.requestContext?.authorizer?.claims?.sub;

    const query = `
      SELECT c.id, c.name
      FROM chats c
      JOIN chat_users cu ON cu.chat_id = c.id
      WHERE cu.user_id = $1
      ORDER BY c.name ASC
    `;

    const res = await client.query(query, [userId]);
    const chats = res.rows;

    return jsonResponse(200, { chats });

  } catch (err) {
    console.error("Database error:", err);
    return jsonResponse(500, { error: "Internal server error" });
  } finally {
    client.release();
  }
};

function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
}