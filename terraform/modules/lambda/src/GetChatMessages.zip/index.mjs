const { Pool } = await import('pg');
import { validate as isUuid } from 'uuid';

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: 5432,
  ssl: { rejectUnauthorized: false }
});


export const handler = async (event) => {
  const client = await pool.connect();

  try {
    const chatId = event.pathParameters?.id;
    const userId =
          event.requestContext?.authorizer?.jwt?.claims?.sub ??
          event.requestContext?.authorizer?.claims?.sub;

    if (!chatId) {
      console.error("Error: Chat ID not provided");
      return jsonResponse(400, { error: "Chat ID not provided" });
    }

    if (!isUuid(chatId)) {
      console.error("Error: Invalid UUID format");
      return jsonResponse(400, { error: "Invalid UUID format" });
    }

    const isMember = await isUserMemberOfChat(client, userId, chatId);

    if (!isMember) {
      return jsonResponse(403, { error: 'You are not member of this chat' });
    }

    const messages = await getChatMessages(client, chatId);

    return jsonResponse(200, { messages });

  } catch (err) {
    console.error("Error in FetchChatMembers error:", err);
    return jsonResponse(500, { error: "Internal server error" });
  } finally {
    client.release();
  }
};

async function isUserMemberOfChat(client, userId, chatId) {
  const res = await client.query(
    `SELECT 1 FROM chat_users WHERE chat_id = $1 AND user_id = $2 LIMIT 1`,
    [chatId, userId]
  );
  return res.rowCount > 0;
}

async function getChatMessages(client, chatId) {
  const res = await client.query(
    `SELECT id, user_id, chat_id, content, timestamp FROM chat_messages WHERE chat_id = $1 ORDER BY timestamp DESC`,
    [chatId]
  );
  return res.rows;
}

function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
}