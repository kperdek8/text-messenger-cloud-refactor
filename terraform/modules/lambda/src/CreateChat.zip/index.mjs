const { Pool } = await import('pg');
import { v4 as uuidv4 } from 'uuid';
import { SQSClient, SendMessageCommand } from "@aws-sdk/client-sqs";

const sqs = new SQSClient({
   region: "us-east-1"
});

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: 5432,
  ssl: { rejectUnauthorized: false }
});

export const handler = async (event) => {
  const client = await pool.connect();
  try {
    const queryParams = event.queryStringParameters;
    const chatName = queryParams?.name;

    if (!chatName) {
      return jsonResponse(400, { error: 'Chat name is required' });
    }

    const userId =
      event.requestContext?.authorizer?.jwt?.claims?.sub ??
      event.requestContext?.authorizer?.claims?.sub;

    if (!userId) {
      console.error('User ID not found in requestContext');
      return jsonResponse(500, { error: 'Internal server error' });
    }

    console.info(`Creating chat ${chatName} for user ${userId}`);

    // 1. Create chat
    const id = uuidv4();
    const now = new Date().toISOString();
    const chatRes = await client.query(
      'INSERT INTO chats (id, name, inserted_at, updated_at) VALUES ($1, $2, $3, $4) RETURNING id, name',
      [id, chatName, now, now]
    );
    const chat = chatRes.rows[0];

    // 2. Add user to chat (if not already)
    const userCheck = await client.query(
      'SELECT 1 FROM chat_users WHERE chat_id = $1 AND user_id = $2',
      [chat.id, userId]
    );

    if (userCheck.rowCount === 0) {
      console.info(`Adding user ${userId} to chat ${chat.id}`);
      await client.query(
        'INSERT INTO chat_users (chat_id, user_id) VALUES ($1, $2)',
        [chat.id, userId]
      );
    } else {
      return jsonResponse(409, { error: 'User already in chat' });
    }

    // 3. Send SQS message
    console.info(`Producing SQS message for chat ${chat.id}`);
    const messageCommand = new SendMessageCommand({
      QueueUrl: process.env.SQS_URL,
      MessageBody: JSON.stringify({
        event: 'chat.created',
        data: { chat_id: chat.id, user_id: userId },
      }),
    });
    await sqs.send(messageCommand);
    // 4. Return response
    return jsonResponse(200, chat);

  } catch (error) {
    console.error('Error:', error);
    return jsonResponse(500, { error: error.message });
  } finally {
    client.release();
  }
};

function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
}